package network;

import java.net.*;  
import java.io.*;  
public class TCPClient1{  
public static void main(String args[])throws Exception{  
	String sentence=" ";
	String modifiedSentence=" "; 
Socket clientSocket=new Socket("localhost",4444);  
DataInputStream inFromServer=new DataInputStream(clientSocket.getInputStream());  
DataOutputStream outToServer=new DataOutputStream(clientSocket.getOutputStream());  
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

while(true){  
sentence=br.readLine();  
outToServer.writeUTF(sentence);  
outToServer.flush();  
modifiedSentence=inFromServer.readUTF();  
System.out.println("Server says: "+modifiedSentence);  

}
}  
}